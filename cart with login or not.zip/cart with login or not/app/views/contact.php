
<?php include'header.php'; ?>

<style> .icon-cont {color:F27523; font-size:100px} 
.input-cont{border: 1.5px solid #F27523}</style>
<div class="row">
  <!--<iframe src="https://maps.google.com/maps?width=1139&amp;height=436&amp;hl=en&amp;q=%20taiz+(map%20)&amp;t=h&amp;z=12&amp;ie=UTF8&amp;iwloc=B&amp;output=embed" width="100%" height="320" frameborder="0" style="border:0" allowfullscreen></iframe>-->
  <iframe src="https://maps.google.com/maps?width=1139&amp;height=436&amp;hl=en&amp;q=%20%D8%A7%D9%84%D8%B3%D8%AA%D9%8A%D9%86%20%D8%AC%D9%88%D9%84%D8%A9%20%D8%A7%D9%84%D9%85%D8%B5%D8%A8%D8%A7%D8%AD%D9%8A%20sanaa+(map%20)&amp;t=h&amp;z=12&amp;ie=UTF8&amp;iwloc=B&amp;output=embed" width="100%" height="320" frameborder="0" style="border:0" allowfullscreen></iframe>
 </div>

 <hr>
    </section>
    <section id="contact">
       <div class="container">
          <div class="row">
          <div class="col-sm-12 col-md-6 col-lg-3 my-5">
               <div class="card border-0">
                  <div class="card-body text-center">
                    <i class="fa fa-map-marker fa-5x mb-3" aria-hidden="true"></i>
                    <h4 >راسلنا </h4>
                    <h1 class="ion-ios-chatboxes icon-cont" ></h1>
                    <address>راسلنا ليصلك ما تريد  </address>
                  </div>
                </div>
             </div>
             <div class="col-sm-12 col-md-6 col-lg-3 my-5">
               <div class="card border-0">
                  <div class="card-body text-center">
                    <i class="fa fa-phone fa-5x mb-3" aria-hidden="true"></i>
                    <h4 >اتصل بنا</h4>
                    <h1 class="ion-android-call icon-cont"></h1>
                    <p>+967734256894,+967977123465</p>
                  </div>
                </div>
             </div>
             <div class="col-sm-12 col-md-6 col-lg-3 my-5">
               <div class="card border-0">
                  <div class="card-body text-center">
                    <i class="fa fa-map-marker fa-5x mb-3" aria-hidden="true"></i>
                    <h4 >office loaction</h4>
                    <h1 class="ion-ios-location icon-cont"></h1>
                   <address>اليمن صنعاء - تعز   </address>
                  </div>
                </div>
             </div>
             
             <div class="col-sm-12 col-md-6 col-lg-3 my-5">
               <div class="card border-0">
                  <div class="card-body text-center">
                    <i class="fa fa-globe fa-5x mb-3" aria-hidden="true"></i>
                    <h4 >ايميل </h4>
                    <h1 class="ion-android-mail icon-cont"></h1>
                    <p>http://al.a.webdev@gmail.com</p>
                  </div>
                </div>
             </div>
           </div>
       </div>
 
    </section>
    <br><hr> <br>

<section class="contact">
	

<div class="container-fluid ">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            </br>
  </br>
            <img class="" width="100%" alt="image" src="app/assets/img/contactus.png"/>
        </div> 
         <div class="col-md-6 col-sm-12 ">
               <div class="">
                  <h3 class="text-right" style="color: #000;"> تواصل معنا</h3>
  </br>
                <form  class="text-right" role="form" action=""  method="POST">
						<div class="form-group col-sm-12" style="float:right;">
						 <label class="text-labe">الاسم </label>
              <input type="text" name="name" value="" class="form-control text-right input-cont"   placeholder=" ادخل اسمك">   
            </div>
            <div class="form-group col-sm-12" style="float:right;"> 
                <label class="text-labe">البريد الالكتروني </label>
                <input type="email"  name="email" class="form-control text-right input-cont" value="" placeholder="ادخل بريدك  ">   
            </div>	   
					  	<!--<div class="form-group">
					    	<label for="countery" class="text-labe"> الدولة </label>
					    	<input type="countery" class="form-control" id="countery" placeholder=" ادخل اسم دولتك ">
						</div>-->
                      <div class="form-group col-sm-12" style="float:right;" >
			  				<label for ="description" class="text-labe">  رسالتك الينا</label>
			  			 	<textarea type="text" class="form-control text-right input-cont" id="description" name="message" placeholder="اكتب ما تريد توصيله لنا " style="height: 6.1em;"></textarea>
			  			</div>
			  			<div class="form-group" style="float:left; padding:3px 20px" >
			  				<button type="button" class="btn btn-default submit input-cont" ><i class="ion-ios-paperplane" ></i> ارسال الرسالة </button>
			  			</div>
			  			
          
				</form>
			</div>
		</div> 
	</div>
</div>

<?php include'footer.php'; ?>