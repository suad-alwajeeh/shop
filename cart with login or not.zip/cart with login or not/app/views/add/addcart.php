<?php 
include"app/views/header.php";
echo"iiiiiiiiiiiiiiiiii";
include"../footer.php";

?>