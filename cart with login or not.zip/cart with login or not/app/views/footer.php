<!--================ Start Footer Area =================-->

	<footer class="footer-area section-gap">
		<div class="container ">
			<div class="row">
				<div class="col-lg-12" style="">
					<div class="text-center">
						<h4 style="text-center">
متجر الكتروني لبيع المنتجات الالكترونيه
                            </br>
                        </h4>
                    </div>
				</div>
            <div class="col-md-4 col-sm-12 " style="">
					<div class="text-center">
                       
						<ul>
                         <h6>روابط عامة</h6>    
                            <li>من نحن</li>
                            <li>العروض </li>
                            <li> تواصل معنا</li>                            
                        </ul>
                    </div>
				</div>
            <div class="col-md-4 col-sm-12" style="">
					<div class="text-center">
                        
						<ul>
                            <h6> الاصناف</h6>
                            <li>موبايلات</li>
                            <li>لابتوبات </li>
                            <li>  تابليتات</li>                            
                        </ul>
                    </div>
				</div>
            <div class="col-md-4 col-sm-12" style="">
					<div class="text-center">
						<ul>
                       <h6>للتواصل </h6>
                            <li><span class="ion-social-facebook-outline"></span>:www.facebook.com </li>
                            <li><span class="ion-social-whatsapp-outline"></span>:www.whatsapp.com </li>
                            <li><span class="ion-social-twitter-outline"></span>:www.twitter.com</li>                            
                        </ul>
                    </div>
				</div>
            <div class="col-lg-12 foo" style="">
					<div class="text-center">
						<p style="text-center ;color:white">
                            @2020حقوق الطبع محفوظة لفريق <span style="color:#ff6500;">webDev</span>          
                        </p>
                    </div>
				</div>
			</div>
        </div>

	</footer>
</body>
</html>
